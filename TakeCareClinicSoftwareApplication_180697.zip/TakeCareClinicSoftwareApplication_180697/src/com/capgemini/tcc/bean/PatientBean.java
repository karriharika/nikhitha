package com.capgemini.tcc.bean;

public class PatientBean {
	private String patientId;
	private String patientName;
	private String age;
	private String phone;
	private String description;
	private String consultationDate;

	public PatientBean() {
		
	}

	public PatientBean(String patientId, String patientName, String age,
			String phone, String description, String consultationDate) {
		super();
		this.patientId = patientId;
		this.patientName = patientName;
		this.age = age;
		this.phone = phone;
		this.description = description;
		this.consultationDate = consultationDate;
	}

	public String getPatientId() {
		return patientId;
	}

	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getConsultationDate() {
		return consultationDate;
	}

	public void setConsultationDate(String consultationDate) {
		this.consultationDate = consultationDate;
	}

	@Override
	public String toString() {
		return "PatientBean [patientId=" + patientId + ", patientName="
				+ patientName + ", age=" + age + ", phone=" + phone
				+ ", description=" + description + ", consultationDate="
				+ consultationDate + "]";
	}
	
	
	
}
