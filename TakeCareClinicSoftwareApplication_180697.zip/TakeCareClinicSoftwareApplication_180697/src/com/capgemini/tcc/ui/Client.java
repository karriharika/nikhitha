package com.capgemini.tcc.ui;
import java.util.Scanner;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.PatientException;
import com.capgemini.tcc.service.IPatientService;
import com.capgemini.tcc.service.PatientService;

public class Client {

	public static void main(String[] args) {
		IPatientService ser = new PatientService();
		Scanner sc = new Scanner(System.in);
		do {
			System.out.println("             SELECT MENU               ");
			System.out.println("       1. Add Patient Information           ");
			System.out.println("       2. Search Patient by ID      ");
			System.out.println("       3. Exit                            ");
			System.out.println("Please Enter your choice\n");
			String choice = sc.nextLine();
			switch (choice) {
			case "1":
				System.out.println("Enter the Name of the Patient : ");
				String pname = sc.nextLine();
				System.out.println("Enter patient age : ");
				String page = sc.nextLine();
				System.out.println("Enter patient phone number : ");
				String pphone = sc.nextLine();
				System.out.println("Enter description : ");
				String pdesc = sc.nextLine();
				PatientBean bean = new PatientBean(null, pname,page, pphone, pdesc, null);
				try {
					if (ser.isValidPatient(bean)) {
						String eid = ser.addPatientDetails(bean);
						System.out.println("Patient information stored successfully for patient Id" + bean.getPatientId());
					}
				} catch (PatientException e) {
					System.err.println(e.getMessage());
				}
				break;
			case "2":
				System.out.println("Please enter the patient id you want to serch");
				String patientId = sc.nextLine();
				try{
					System.out.println("Search result is :\n");
					PatientBean patientBean;
					patientBean = ser.getPatientDeatails(patientId);
					if (patientBean==null) {
						System.err.println("Sorry no details found with id "+ patientId);
					}else{
						System.out.println("Patient Name  : "+patientBean.getPatientName());
						System.out.println("Patient Age  : "+patientBean.getAge());
						System.out.println("Contact No  : "+patientBean.getPhone());
						System.out.println("Description      : "+patientBean.getDescription());
						System.out.println("Consultation Date    : "+patientBean.getConsultationDate());
					}
				}catch(PatientException e){
					System.err.println("There is no patient with id "+patientId + e.getMessage());
				}
				break;
			case "3":
				System.exit(0);
				break;
			default:
				System.err.println("Please Enter Valid Choice");
				break;
			}

		} while (true);

	}

}
