package com.capgemini.tcc.service;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.PatientException;

public interface IPatientService {
	String addPatientDetails(PatientBean patient) throws PatientException;
	PatientBean getPatientDeatails(String patientId) throws PatientException;
	Boolean isValidPatient(PatientBean patientBean) throws PatientException;
}
