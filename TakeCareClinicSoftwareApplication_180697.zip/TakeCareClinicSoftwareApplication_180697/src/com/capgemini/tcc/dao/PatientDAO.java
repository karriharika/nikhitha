package com.capgemini.tcc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.PatientException;
import com.capgemini.tcc.util.DBUtil;

public class PatientDAO implements IPatientDAO {
	Connection conn = null;
	
	private String generatePatientId() throws PatientException{
		String pid = null;
		try {
			conn = DBUtil.getConnection();
			Statement stmt = conn.createStatement();
			ResultSet rst  = stmt.executeQuery(QueryMapper.PATIENTID_SEQUENCE_QUERY);
			while(rst.next()){
				pid = rst.getString(1);
			}
		} catch (SQLException e) {
			throw new PatientException("Problem in generating patient id");
		}
		return pid;	
	}
	@Override
	public String addPatientDetails(PatientBean patient) throws PatientException {
		patient.setPatientId(generatePatientId());
		try {
			conn = DBUtil.getConnection();
			PreparedStatement pst = conn.prepareStatement(QueryMapper.ADD_PATIENT);
			pst.setString(1, patient.getPatientId());
			pst.setString(2, patient.getPatientName());
			pst.setString(3, patient.getAge());
			pst.setString(4, patient.getPhone());
			pst.setString(5, patient.getDescription());
			pst.executeUpdate();
		} catch (SQLException e) {
			throw new PatientException("Problem in adding patient details\n");
		}
		return patient.getPatientId();
	}

	@Override
	public PatientBean getPatientDeatails(String patientId) throws PatientException{
		PatientBean pbean = null;
		try {
			conn = DBUtil.getConnection();
			PreparedStatement pst = conn.prepareStatement(QueryMapper.GET_PATIENT_DETAILS);
			pst.setString(1, patientId);
			ResultSet rst = pst.executeQuery();
			if(rst.next()){
				pbean = new PatientBean();
				pbean.setPatientId(rst.getString("patient_id"));
				pbean.setPatientName(rst.getString("patient_name"));
				pbean.setAge(rst.getString("age"));
				pbean.setPhone(rst.getString("phone"));
				pbean.setDescription(rst.getString("description"));
				pbean.setConsultationDate(rst.getString("consultation_date"));
			}
		} catch (SQLException e) {
			throw new PatientException("Problem in searching patient details\n");
		}
		return pbean;
	}

}
