package com.capgemini.tcc.dao;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.PatientException;

public interface IPatientDAO {
	String addPatientDetails(PatientBean patient) throws  PatientException;
	PatientBean getPatientDeatails(String patientId) throws PatientException;
}
